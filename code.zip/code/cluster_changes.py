'''
This script is used to cluster code changes per commit
or non-atomic
'''
import logging
import os.path
import connected_components

import itertools
import signal
import numpy as np
import util

from sklearn.cluster import DBSCAN, OPTICS, AgglomerativeClustering


def process_gumtree_output(changes_file, output_file):
    """
    This script processes the Gumtree output into the dictionary function_actions
    :param output_file:
    :param changes_file: the file with the GumTree output
    :return:
    """
    logging.info("Processing the gumtree output.")
    try:
        if not os.path.isfile(output_file):
            function_actions = {}
            with open(changes_file, "r") as rfi:
                for line in rfi:
                    # we use :&^ as the separation string because the gumtree output can contain random strings
                    function, action = line.strip().split(":&^")
                    if function in function_actions.keys():
                        function_actions[function].append(action)
                    else:
                        function_actions[function] = [action]
            util.dump_objects(function_actions, output_file)
        else:
            function_actions = util.load_objects(output_file)
            logging.info("Processed gumtree output already present.")
        return function_actions
    except Exception as err:
        failure_file = util.get_failure_file(output_file)
        with open(failure_file, "w") as fi:
            fi.write(f"Failure in obtaining gumtree output {err=} : {type(err)=}")
        return None


def join_code_changes(function_actions, output_file):
    """
    This script further processes the gumtree output by joining all the changes into one string.
    This is a preprocessing step for our approach
    :return:
    """
    logging.info("Joining the code changes.")
    try:
        if not os.path.isfile(output_file):
            function_code_changes = {}
            for key, values in function_actions.items():
                code_change = ''
                for value in values:
                    code_change += value + "\n"
                function_code_changes[key] = code_change.strip()
            util.dump_objects(function_code_changes, output_file)
        else:
            function_code_changes = util.load_objects(output_file)
            logging.info("Joint code changes already present.")
        return function_code_changes
    except Exception as err:
        failure_file = util.get_failure_file(output_file)
        with open(failure_file, "w") as fi:
            fi.write(f"Failure in joining code changes {err=} : {type(err)=}")
        return None


def lcs_lens(xs, ys):
    """
    The longest common subsequence helper
    :param xs:
    :param ys:
    :return:
    """
    curr = list(itertools.repeat(0, 1 + len(ys)))
    for x in xs:
        prev = list(curr)
        for i, y in enumerate(ys):
            if x == y:
                curr[i + 1] = prev[i] + 1
            else:
                curr[i + 1] = max(curr[i], prev[i + 1])
    return curr


def lcs(xs, ys):
    """
    Computes the longest common subsequence of two strings
    :param xs: first string
    :param ys: second string
    :return: the longest common subsequence
    """
    nx, ny = len(xs), len(ys)
    if nx == 0:
        return []
    elif nx == 1:
        return [xs[0]] if xs[0] in ys else []
    else:
        i = nx // 2
        xb, xe = xs[:i], xs[i:]
        ll_b = lcs_lens(xb, ys)
        ll_e = lcs_lens(xe[::-1], ys[::-1])
        _, k = max((ll_b[j] + ll_e[ny - j], j)
                   for j in range(ny + 1))
        yb, ye = ys[:k], ys[k:]
        return lcs(xb, yb) + lcs(xe, ye)


def calculate_similarity(a, b):
    """
    calculate the similarity between two string based on the longest common subsequence
    :param a:
    :param b:
    :return:
    """
    return len(lcs(a, b)) / max(len(a), len(b))


def calculate_similarity_matrix(function_keys, function_code_changes, output_file):
    """
    get the similarity matrix between all code changes
    :return:
    """
    logging.info("Calculating the similarity matrix.")
    try:
        if not os.path.isfile(output_file):
            similarity_matrix = [[0 for _ in range(len(function_keys))] for _ in range(len(function_keys))]
            for index0, function0 in enumerate(function_keys):
                value0 = function_code_changes[function0]
                for index1, function1 in enumerate(function_keys):
                    if index0 != index1:
                        value1 = function_code_changes[function1]
                        similarity = calculate_similarity(value0, value1)
                        similarity_matrix[index0][index1] = similarity
                    else:
                        similarity_matrix[index0][index1] = 1
            util.dump_objects(similarity_matrix, output_file)
        else:
            similarity_matrix = util.load_objects(output_file)
            logging.info("Similarity matrix already present.")
        return similarity_matrix
    except Exception as err:
        failure_file = util.get_failure_file(output_file)
        with open(failure_file, "w") as fi:
            fi.write(f"Failure in obtaining gumtree output {err=} : {type(err)=}")
        return None


def get_connected_components(function_keys, similarity_matrix, output_file):
    logging.info("Obtaining the connected components.")
    try:
        if not os.path.isfile(output_file):
            graph = connected_components.Graph(len(function_keys))
            for index0, sim_list in enumerate(similarity_matrix):
                for index1, sim in enumerate(sim_list):
                    if sim > 0:
                        graph.addEdge(index0, index1, sim)
            cc = graph.getConnectedComponents()
            util.dump_objects(cc, output_file)
        else:
            cc = util.load_objects(output_file)
            logging.info("Connected components already obtained.")
        return cc
    except Exception as err:
        failure_file = util.get_failure_file(output_file)
        with open(failure_file, "w") as fi:
            fi.write(f"Failure in obtaining gumtree output {err=} : {type(err)=}")
        return None


def laplacian_eigenmap(adjacency_matrix, num_components):
    '''
    Computing the laplacian eigenmap of a graph, represented by adjency_matrix, of dimension num_components
    https://www2.imm.dtu.dk/projects/manifold/Papers/Laplacian.pdf
    '''
    # Compute the degree matrix (https://en.wikipedia.org/wiki/Degree_matrix)
    degree_matrix = np.sum(adjacency_matrix, axis=0)
    degree_matrix = np.diag(degree_matrix)

    # Compute the Laplacian matrix (https://en.wikipedia.org/wiki/Laplacian_matrix)
    laplacian_matrix = degree_matrix - adjacency_matrix

    # Compute the eigendecomposition of the Laplacian matrix
    # the eigen vectors are then sorted based on their eigen values
    eigenvalues, eigenvectors = np.linalg.eigh(laplacian_matrix)
    sorted_indices = np.argsort(eigenvalues)
    eigenvectors = eigenvectors[:, sorted_indices]

    # Select the num_components smallest eigenvectors, ignoring the first vector which is the same for all
    # points
    eigenvectors = eigenvectors[:, 1:num_components + 1]

    # Normalize the eigenvectors
    eigenvectors = eigenvectors / np.linalg.norm(eigenvectors, axis=1, keepdims=True)
    return eigenvectors


def reject_outliers(data, m=3):
    return data[abs(data - np.mean(data)) < m * np.std(data)]

def safe_div(x,y):
    if y == 0:
        return 0
    return x / y

def largest_gap_indices(points, category="diff"):
    '''
    Get the largest gap between distances, to serve as our epsilon in the DBSCAN
    :param points:
    :return:
    '''
    # Calculate the distances between each pair of points
    distances = np.sqrt(((points[:, None, :] - points) ** 2).sum(-1))

    # Flatten the distance matrix and sort the distances
    distances = reject_outliers(np.triu(distances, 1).flatten())
    distances_sorted = np.sort(distances)
    distances_sorted_indices = np.argsort(distances)

    # Calculate the differences between consecutive distances
    # Note that the original paper uses division rather than difference
    # In our experience this has proven to be not so good, but we might want to reconsider this
    if category == "diff":
        differences = np.diff(distances_sorted)
    else:
        differences = [safe_div(x2, x1) for (x1, x2) in zip(distances_sorted, distances_sorted[1:])]
    # Find the index of the largest gap between two consecutive differences
    largest_gap_index = np.argmax(differences)

    # Find the index of the lower distances that have the largest gap
    index1 = distances_sorted_indices[largest_gap_index]
    index2 = distances_sorted_indices[largest_gap_index+1]

    lower_bound = distances[index1]
    upper_bound = distances[index2]
    return lower_bound, upper_bound, distances_sorted[-1], distances_sorted

def partition_similarity_matrix(cc, similarity_matrix, function_keys, output_file):
    """
    we partition the graph based on connected components
    so that it's easier for clustering
    :param output_file:
    :param cc:
    :param similarity_matrix:
    :return:
    """
    logging.info("Partitioning the similarity matrix.")
    try:
        if not os.path.isfile(output_file):
            partitions = []
            for root, component_members in cc.items():
                partitioned_graph = [[0 for _ in range(len(component_members))] for _ in range(len(component_members))]
                partition_functions = []
                for index0, member0 in enumerate(component_members):
                    for index1, member1 in enumerate(component_members):
                        similarity = similarity_matrix[member0][member1]
                        partitioned_graph[index0][index1] = similarity
                    function0 = function_keys[member0]
                    partition_functions.append(function0)
                partitions.append((partitioned_graph, partition_functions))
            util.dump_objects(partitions, output_file)
        else:
            partitions = util.load_objects(output_file)
            logging.info("The similarity matrix is already partitioned.")
        return partitions
    except Exception as err:
        failure_file = util.get_failure_file(output_file)
        with open(failure_file, "w") as fi:
            fi.write(f"Failure in obtaining gumtree output {err=} : {type(err)=}")
        return None

def clustering_with_optimization(distances, clustering_algorithm, eigenmap_graph, partition_keys):
    distances_to_cluster_functions = []
    for index, distance in enumerate(distances):
        if distance == 0.0:
            continue
        entry = {}
        entry["index"] = str(index)
        entry["length"] = str(len(distances))
        logging.info(f"index: {index}")
        entry["eps"] = str(distance)
        logging.info(f"eps: {distance}")
        if clustering_algorithm == "DB":
            db = DBSCAN(eps=distance, min_samples=1).fit(eigenmap_graph)
        else:
            db = AgglomerativeClustering(n_clusters = None, distance_threshold=lower_bound).fit(eigenmap_graph)
        labels = db.labels_

            # Number of clusters in labels, ignoring noise if present.
        n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise_ = list(labels).count(-1)

        print("Estimated number of clusters: %d" % n_clusters_)
        print("Estimated number of noise points: %d" % n_noise_)
        clusters_to_functions = {}
        for indexj, label in enumerate(labels):
            if label in clusters_to_functions.keys():
                clusters_to_functions[label].append(partition_keys[indexj])
            else:
                clusters_to_functions[label] = [partition_keys[indexj]]
        entry["clusters_to_functions"] = clusters_to_functions
        distances_to_cluster_functions.append(entry)
    if len(distances_to_cluster_functions) == 0:
        entry={}
        entry["index"] = str(-1)
        entry["eps"] = str(0.0)
        clusters_to_functions = []
        label_final = str(1)
        if label_final in clusters_to_functions.keys():
            for elem in partition_keys:
                clusters_to_functions[label_final].append(elem)
        else:
            clusters_to_functions[label_final] = partition_keys
        entry["clusters_to_functions"] = clusters_to_functions
        distances_to_cluster_functions.append(entry)
    return distances_to_cluster_functions

def find_similarity_bounds(similarity_matrix):
    min = -1
    max = -1

    for i, sim_list in enumerate(similarity_matrix):
        for j, sim in enumerate(sim_list):
            if i ==0 and j == 0:
                min = sim
                max = sim
            if i==j:
                continue
            if sim < min:
                min = sim
            if max > sim:
                max = sim
    return min, max

def similarity_based_clustering(sim_min, function_keys):
    '''
    A very simple clustering method that essentially concludes that changes are atomic with repetition (there is only
    cluster of changes) if the minimum sim is 0.7 between any two changes. Heuristically derived the 0.7
    to be used only when we care for atomic with repetition commits cause it doesn't care about other clusters
    :param sim_min:
    :param clustering_output:
    :param function_keys:
    :return:
    '''
    if sim_min > 0.70:
        clusters_to_functions = {}
        clusters_to_functions[1] = function_keys
        return clusters_to_functions
    return None
def handler(signum, frame):
    print("Forever is over!")
    raise Exception("end of time")

def cluster(gumtree_file, output_dir, cluster_algorithm = "SIM", threshold_selection = "div", bound_selection ="lower",
            optimization=False, clustering_output="default"):
    '''
    Function to cluster the changes
    :param output_dir: the directory where the output should be stored
    :param gumtree_file:
    :return:
    '''
    if clustering_output == "default":
        clustering_output = output_dir
    logging.info(f"Clustering in {output_dir}.")
    logging.info("Initiating clustering.")
    os.makedirs(output_dir, exist_ok=True)
    files = [f for f in os.listdir(output_dir) if os.path.isfile(os.path.join(output_dir, f))]
    if "failure" in files:
        logging.warning("Failure file found. Please check, fix and delete before continuing.")
        return

    function_actions_file = f"{output_dir}/function_actions.pkl"
    function_actions = process_gumtree_output(gumtree_file, function_actions_file)
    if function_actions is None:
        logging.warning("Failure in processing gumtree output.")
        return
    logging.info("Processing of the gumtree output completed successfully.")

    function_code_changes_file = f"{output_dir}/function_code_changes.pkl"
    function_code_changes = join_code_changes(function_actions, function_code_changes_file)

    if function_code_changes is None:
        logging.warning("Failure in obtaining code changes.")
        return
    logging.info("Obtaining of the code changes completed successfully.")

    function_keys_file = f"{output_dir}/function_keys.pkl"
    if not os.path.isfile(function_keys_file):
        function_keys = list(function_code_changes.keys())
        util.dump_objects(function_keys, function_keys_file)
    else:
        function_keys = util.load_objects(function_keys_file)
    signal.signal(signal.SIGALRM, handler)
    signal.alarm(6000)
    similarity_matrix_file = f"{output_dir}/similarity_matrix.pkl"
    try:
        similarity_matrix = calculate_similarity_matrix(function_keys, function_code_changes, similarity_matrix_file)
        if similarity_matrix is None:
            logging.warning("Failure in obtaining the similarity matrix.")
            return
    except:
        logging.warning("The similarity processing took too long. Aborting.")
        signal.alarm(0)
        return
    signal.alarm(0)
    logging.info("Calculating of the similarity matrix completed successfully.")
    clusters_to_functions_file = f"{clustering_output}/clusters_to_functions.pkl"
    sim_min, sim_max = find_similarity_bounds(similarity_matrix)
    sim_based_clusters = similarity_based_clustering(sim_min, function_keys)
    if cluster_algorithm == "SIM":
        util.dump_objects(sim_based_clusters, clusters_to_functions_file)
        return sim_based_clusters
    else:
        if sim_based_clusters is not None:
            util.dump_objects(sim_based_clusters, clusters_to_functions_file)
            np_sim_matrix = np.array(similarity_matrix)
            logging.info(f"np  sim matrix {np_sim_matrix}")
            eigenmap_graph = laplacian_eigenmap(np_sim_matrix, 3)
            logging.info(f"eigenmap graph {eigenmap_graph}")
            return sim_based_clusters
        else:
            cc_file = f"{output_dir}/sim_matrix_connected_components.pkl"
            cc = get_connected_components(function_keys, similarity_matrix, cc_file)

            if cc is None:
                logging.warning("Failure in obtaining the connected components.")
                return
            logging.info("Obtaining of the connected components completed successfully.")

            partitions_file = f"{output_dir}/partitions.pkl"
            partitions = partition_similarity_matrix(cc, similarity_matrix, function_keys, partitions_file)

            if partitions is None:
                logging.warn("Failure in obtaining partitions.")
                return
            logging.info("Obtaining of the partitions completed successfully.")

            logging.info("Initiating the clustering.")
            clusters_to_functions_file = f"{clustering_output}/clusters_to_functions.pkl"
            try:
                if not os.path.isfile(clusters_to_functions_file):
                    clusters_to_functions = {}
                    for index, partition in enumerate(partitions):
                        clusters_to_functions = {}
                        logging.info(f"Partition {index}")
                        partitioned_similarity_matrix, partition_keys = partition
                        np_sim_matrix = np.array(partitioned_similarity_matrix)
                        eigenmap_graph = laplacian_eigenmap(np_sim_matrix, 2)
                        lower_bound, upper_bound, max, distances_sorted = largest_gap_indices(eigenmap_graph, threshold_selection)
                        if bound_selection == "lower":
                            bound = lower_bound
                        elif bound_selection == "upper":
                            bound = upper_bound
                        else:
                            bound = max
                        if optimization:
                            distances_to_functions = clustering_with_optimization(distances_sorted, cluster_algorithm, eigenmap_graph, partition_keys)
                            for entry in distances_to_functions:
                                entry_index = entry["index"]
                                length = entry["length"]
                                eps = entry["eps"]
                                clusters_to_functions = entry["clusters_to_functions"]
                                logging.info(f"entry index: {entry_index}")
                                os.makedirs(os.path.join(clustering_output, f"{entry_index}@{length}@{eps}"))
                                clusters_to_functions_file = f"{clustering_output}/{entry_index}@{length}@{eps}/clusters_to_functions.pkl"
                                util.dump_objects(clusters_to_functions, clusters_to_functions_file)
                            return distances_to_functions
                        else:
                            if bound == 0.0:
                                label_final = f"{str(index)}{str(1)}"
                                if label_final in clusters_to_functions.keys():
                                    for elem in partition_keys:
                                        clusters_to_functions[label_final].append(elem)
                                else:
                                    clusters_to_functions[label_final] = partition_keys
                            else:
                                if cluster_algorithm == "DB":
                                    db = DBSCAN(eps=bound, min_samples=1).fit(eigenmap_graph)
                                else:
                                    db = AgglomerativeClustering(n_clusters = None, distance_threshold=bound).fit(eigenmap_graph)
                                labels = db.labels_

                                # Number of clusters in labels, ignoring noise if present.
                                n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
                                n_noise_ = list(labels).count(-1)

                                print("Estimated number of clusters: %d" % n_clusters_)
                                print("Estimated number of noise points: %d" % n_noise_)

                                for indexj, label in enumerate(labels):
                                    label_final = f"{str(index)}{str(label)}"
                                    if label_final in clusters_to_functions.keys():
                                        clusters_to_functions[label_final].append(partition_keys[indexj])
                                    else:
                                        clusters_to_functions[label_final] = [partition_keys[indexj]]
                    util.dump_objects(clusters_to_functions, clusters_to_functions_file)
                else:
                    clusters_to_functions = util.load_objects(clusters_to_functions_file)
                    logging.info("Clustering already present.")
                return clusters_to_functions
            except Exception as err:
                failure_file = util.get_failure_file(clusters_to_functions_file)
                with open(failure_file, "w") as fi:
                    fi.write(f"Failure in clustering {err=} : {type(err)=}")
                return None
if __name__ == "__main__":

    argparser = argparse.ArgumentParser(
        description="Determine if commits are atomic with repetitions or non-atomic")

    argparser.add_argument("-o", "--output", help="Path to the input/output dir.")
    args = argparser.parse_args()
    output_dir = args.output
    gumtree_output = f"{output_dir}/gumtree_output.txt"
    cluster(gumtree_file, output_dir)
