import com.github.gumtreediff.actions.*;
import com.github.gumtreediff.actions.model.*;
import com.github.gumtreediff.client.Option;
import com.github.gumtreediff.client.Run;
import com.github.gumtreediff.gen.c.CTreeGenerator;
import com.github.gumtreediff.gen.srcml.SrcmlCTreeGenerator;
import com.github.gumtreediff.gen.srcml.SrcmlCppTreeGenerator;
import com.github.gumtreediff.io.LineReader;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.utils.Pair;
import org.apache.commons.lang3.StringUtils;

import javax.xml.stream.XMLStreamException;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * In this class, the changes between two files (a vulnerable and fixed version) are obtained
 * gumtree is used to get the diff
 */
public class DiffObtainer {
    /**
     * this method takes as input the path to two versions of a file that has changed, and prints out the changes to a file
     * @param file1
     * @param file2
     * @return
     * @throws IOException
     */
    private String output;
    private PrintWriter pw;
    private String language;
    private HashMap<String, Tree> fileToRoot = new HashMap<>();
    private HashMap<String, Integer> functionNameToParamNumber = new HashMap<>();
    private LineReader l1;
    private LineReader l2;
    HashMap<String, String> filetoLanguage = new HashMap<>();
    boolean expensiveMatching = false;
    boolean actionCleaningNeeded = true;
    boolean deletedPair = false;
    HashMap<String, MappingStore> fileToMappingStore = new HashMap<>();

    public void setGetPotentialCasualtiesOnly(boolean getPotentialCasualtiesOnly) {
        this.getPotentialCasualtiesOnly = getPotentialCasualtiesOnly;
    }

    boolean getPotentialCasualtiesOnly = false;

    public static final int INSERT_NODE = 0;
    public static final int INSERT_TREE = 1;
    public static final int DELETE_NODE = 2;
    public static final int DELETE_TREE = 3;
    public static final int UPDATE_NODE = 4;
    public static final int UPDATE_TREE = 5;
    public static final int MOVE_NODE = 6;
    public static final int MOVE_TREE = 7;

    private static final Map<String, Integer> nodeTypeToCodes = new HashMap<String, Integer>();

    public static final int ACTMISC_CODE = 8;
    public static final int ARRAYACCESS_CODE = 9;
    public static final int ASM_CODE = 10;
    public static final int ASSIGNMENT_CODE = 11;
    public static final int BASETYPE_CODE = 12;
    public static final int BINARY_CODE = 13;
    public static final int BREAK_CODE = 14;
    public static final int CINT_CODE = 15;
    public static final int CASE_CODE = 16;
    public static final int CAST_CODE = 17;
    public static final int COMPOUND_CODE = 18;
    public static final int CONDEXPR_CODE = 19;
    public static final int CONSTANT_CODE = 20;
    public static final int CONSTRUCTOR_CODE = 21;
    public static final int CONTINUE_CODE = 22;
    public static final int CPPTOP_CODE = 23;
    public static final int DECLLIST_CODE = 24;
    public static final int DECLARATION_CODE = 25;
    public static final int DEFAULT_CODE = 26;
    public static final int DEFINE_CODE = 27;
    public static final int DEFINEDOWHILEZERO_CODE = 28;
    public static final int DEFINEEXPR_CODE = 29;
    public static final int DEFINEFUNC_CODE = 30;
    public static final int DEFINEFUNCTION_CODE = 31;
    public static final int DEFINEINIT_CODE = 32;
    public static final int DEFINEMULTI_CODE = 33;
    public static final int DEFINESTMT_CODE = 34;
    public static final int DEFINETODO_CODE = 35;
    public static final int DEFINEVAR_CODE = 36;
    public static final int DEFINITION_CODE = 37;
    public static final int DESIGNATORFIELD_CODE = 38;
    public static final int DESIGNATORINDEX_CODE = 39;
    public static final int DOWHILE_CODE = 40;
    public static final int DOTSPARAMETER_CODE = 41;
    public static final int EMPTYDEF_CODE = 42;
    public static final int ENUMNAME_CODE = 43;
    public static final int EXPRSTATEMENT_CODE = 44;
    public static final int FINALDEF_CODE = 45;
    public static final int FOR_CODE = 46;
    public static final int FULLTYPE_CODE = 47;
    public static final int FUNCALL_CODE = 48;
    public static final int GENERICLIST_CODE = 49;
    public static final int GENERICSTRING_CODE = 50;
    public static final int GOTO_CODE = 51;
    public static final int IDENT_CODE = 52;
    public static final int IF_CODE = 53;
    public static final int IFTOKEN_CODE = 54;
    public static final int IFDEFDIRECTIVE_CODE = 55;
    public static final int IFDEFTOP_CODE = 56;
    public static final int INCLUDE_CODE = 57;
    public static final int INFIX_CODE = 58;
    public static final int INITDESIGNATORS_CODE = 59;
    public static final int INITEXPR_CODE = 60;
    public static final int INITLIST_CODE = 61;
    public static final int INTTYPE_CODE = 62;
    public static final int LABEL_CODE = 63;
    public static final int LEFT_CODE = 64;
    public static final int MACRODECL_CODE = 65;
    public static final int MACROITERATION_CODE = 66;
    public static final int MACROSTMT_CODE = 67;
    public static final int NONE_CODE = 68;
    public static final int NOTPARSEDCORRECTLY_CODE = 69;
    public static final int OTHERDIRECTIVE_CODE = 70;
    public static final int PARAMLIST_CODE = 71;
    public static final int PARAMETERTYPE_CODE = 72;
    public static final int PARENEXPR_CODE = 73;
    public static final int POINTER_CODE = 74;
    public static final int POSTFIX_CODE = 75;
    public static final int PROGRAM_CODE = 76;
    public static final int PTRDIFFTYPE_CODE = 77;
    public static final int RECORDACCESS_CODE = 78;
    public static final int RECORDPTACCESS_CODE = 79;
    public static final int RETURN_CODE = 80;
    public static final int RETURNEXPR_CODE = 81;
    public static final int SEQUENCE_CODE = 82;
    public static final int SIZEOFEXPR_CODE = 83;
    public static final int SIZEOFTYPE_CODE = 84;
    public static final int SIZETYPE_CODE = 85;
    public static final int SOME_CODE = 86;
    public static final int STATEMENTEXPR_CODE = 87;
    public static final int STORAGE_CODE = 88;
    public static final int STRUCTUNION_CODE = 89;
    public static final int STRUCTUNIONNAME_CODE = 90;
    public static final int SWITCH_CODE = 91;
    public static final int TYPENAME_CODE = 92;
    public static final int TYPEQUALIFIER_CODE = 93;
    public static final int UNSIGNED_CODE = 94;
    public static final int UNARY_CODE = 95;
    public static final int WHILE_CODE = 96;
    public static final int ARGUMENT_CODE = 97;
    public static final int ARGUMENT_LIST_CODE = 98;
    public static final int BLOCK_CODE = 99;
    public static final int BLOCK_CONTENT_CODE = 100;
    public static final int CALL_CODE = 101;
    public static final int CONDITION_CODE = 103;
    public static final int CONTROL_CODE = 104;
    public static final int DECL_CODE = 105;
    public static final int DECL_STMT_CODE = 106;
    public static final int DIRECTIVE_CODE = 108;
    public static final int ELIF_CODE = 109;
    public static final int ELSE_CODE = 110;
    public static final int EMPTY_STMT_CODE = 111;
    public static final int ENDIF_CODE = 112;
    public static final int ENUM_CODE = 113;
    public static final int ERROR_CODE = 114;
    public static final int EXPR_CODE = 115;
    public static final int EXPR_STMT_CODE = 116;
    public static final int FILE_CODE = 117;
    public static final int FUNCTION_CODE = 119;
    public static final int FUNCTION_DECL_CODE = 120;
    public static final int IF_STMT_CODE = 123;
    public static final int IFDEF_CODE = 124;
    public static final int IFNDEF_CODE = 125;
    public static final int INCR_CODE = 127;
    public static final int INDEX_CODE = 128;
    public static final int INIT_CODE = 129;
    public static final int LITERAL_CODE = 131;
    public static final int MACRO_CODE = 132;
    public static final int MODIFIER_CODE = 133;
    public static final int NAME_CODE = 134;
    public static final int NAMESPACE_CODE = 135;
    public static final int OPERATOR_CODE = 136;
    public static final int PARAMETER_CODE = 137;
    public static final int SPECIFIER_CODE = 140;
    public static final int STRUCT_CODE = 141;
    public static final int STRUCT_DECL_CODE = 142;
    public static final int TERNARY_CODE = 143;
    public static final int THEN_CODE = 144;
    public static final int TYPE_CODE = 145;
    public static final int TYPEDEF_CODE = 146;
    public static final int UNDEF_CODE = 147;
    public static final int UNION_CODE = 148;
    public static final int UNIT_CODE = 149;
    public static final int USING_CODE = 150;
    public static final int VALUE_CODE = 151;

    static {
        nodeTypeToCodes.put("ActMisc", ACTMISC_CODE);
        nodeTypeToCodes.put("ArrayAccess", ARRAYACCESS_CODE);
        nodeTypeToCodes.put("Asm", ASM_CODE);
        nodeTypeToCodes.put("Assignment", ASSIGNMENT_CODE);
        nodeTypeToCodes.put("BaseType", BASETYPE_CODE);
        nodeTypeToCodes.put("Binary", BINARY_CODE);
        nodeTypeToCodes.put("Break", BREAK_CODE);
        nodeTypeToCodes.put("CInt", CINT_CODE);
        nodeTypeToCodes.put("Case", CASE_CODE);
        nodeTypeToCodes.put("Cast", CAST_CODE);
        nodeTypeToCodes.put("Compound", COMPOUND_CODE);
        nodeTypeToCodes.put("CondExpr", CONDEXPR_CODE);
        nodeTypeToCodes.put("Constant", CONSTANT_CODE);
        nodeTypeToCodes.put("Constructor", CONSTRUCTOR_CODE);
        nodeTypeToCodes.put("Continue", CONTINUE_CODE);
        nodeTypeToCodes.put("CppTop", CPPTOP_CODE);
        nodeTypeToCodes.put("DeclList", DECLLIST_CODE);
        nodeTypeToCodes.put("Declaration", DECLARATION_CODE);
        nodeTypeToCodes.put("Default", DEFAULT_CODE);
        nodeTypeToCodes.put("Define", DEFINE_CODE);
        nodeTypeToCodes.put("DefineDoWhileZero", DEFINEDOWHILEZERO_CODE);
        nodeTypeToCodes.put("DefineExpr", DEFINEEXPR_CODE);
        nodeTypeToCodes.put("DefineFunc", DEFINEFUNC_CODE);
        nodeTypeToCodes.put("DefineFunction", DEFINEFUNCTION_CODE);
        nodeTypeToCodes.put("DefineInit", DEFINEINIT_CODE);
        nodeTypeToCodes.put("DefineMulti", DEFINEMULTI_CODE);
        nodeTypeToCodes.put("DefineStmt", DEFINESTMT_CODE);
        nodeTypeToCodes.put("DefineTodo", DEFINETODO_CODE);
        nodeTypeToCodes.put("DefineVar", DEFINEVAR_CODE);
        nodeTypeToCodes.put("Definition", DEFINITION_CODE);
        nodeTypeToCodes.put("DesignatorField", DESIGNATORFIELD_CODE);
        nodeTypeToCodes.put("DesignatorIndex", DESIGNATORINDEX_CODE);
        nodeTypeToCodes.put("DoWhile", DOWHILE_CODE);
        nodeTypeToCodes.put("DotsParameter", DOTSPARAMETER_CODE);
        nodeTypeToCodes.put("EmptyDef", EMPTYDEF_CODE);
        nodeTypeToCodes.put("EnumName", ENUMNAME_CODE);
        nodeTypeToCodes.put("ExprStatement", EXPRSTATEMENT_CODE);
        nodeTypeToCodes.put("FinalDef", FINALDEF_CODE);
        nodeTypeToCodes.put("For", FOR_CODE);
        nodeTypeToCodes.put("FullType", FULLTYPE_CODE);
        nodeTypeToCodes.put("FunCall", FUNCALL_CODE);
        nodeTypeToCodes.put("GenericList", GENERICLIST_CODE);
        nodeTypeToCodes.put("GenericString", GENERICSTRING_CODE);
        nodeTypeToCodes.put("Goto", GOTO_CODE);
        nodeTypeToCodes.put("Ident", IDENT_CODE);
        nodeTypeToCodes.put("If", IF_CODE);
        nodeTypeToCodes.put("IfToken", IFTOKEN_CODE);
        nodeTypeToCodes.put("IfdefDirective", IFDEFDIRECTIVE_CODE);
        nodeTypeToCodes.put("IfdefTop", IFDEFTOP_CODE);
        nodeTypeToCodes.put("Include", INCLUDE_CODE);
        nodeTypeToCodes.put("Infix", INFIX_CODE);
        nodeTypeToCodes.put("InitDesignators", INITDESIGNATORS_CODE);
        nodeTypeToCodes.put("InitExpr", INITEXPR_CODE);
        nodeTypeToCodes.put("InitList", INITLIST_CODE);
        nodeTypeToCodes.put("IntType", INTTYPE_CODE);
        nodeTypeToCodes.put("Label", LABEL_CODE);
        nodeTypeToCodes.put("Left", LEFT_CODE);
        nodeTypeToCodes.put("MacroDecl", MACRODECL_CODE);
        nodeTypeToCodes.put("MacroIteration", MACROITERATION_CODE);
        nodeTypeToCodes.put("MacroStmt", MACROSTMT_CODE);
        nodeTypeToCodes.put("None", NONE_CODE);
        nodeTypeToCodes.put("NotParsedCorrectly", NOTPARSEDCORRECTLY_CODE);
        nodeTypeToCodes.put("OtherDirective", OTHERDIRECTIVE_CODE);
        nodeTypeToCodes.put("ParamList", PARAMLIST_CODE);
        nodeTypeToCodes.put("ParameterType", PARAMETERTYPE_CODE);
        nodeTypeToCodes.put("ParenExpr", PARENEXPR_CODE);
        nodeTypeToCodes.put("Pointer", POINTER_CODE);
        nodeTypeToCodes.put("Postfix", POSTFIX_CODE);
        nodeTypeToCodes.put("Program", PROGRAM_CODE);
        nodeTypeToCodes.put("PtrDiffType", PTRDIFFTYPE_CODE);
        nodeTypeToCodes.put("RecordAccess", RECORDACCESS_CODE);
        nodeTypeToCodes.put("RecordPtAccess", RECORDPTACCESS_CODE);
        nodeTypeToCodes.put("Return", RETURN_CODE);
        nodeTypeToCodes.put("ReturnExpr", RETURNEXPR_CODE);
        nodeTypeToCodes.put("Sequence", SEQUENCE_CODE);
        nodeTypeToCodes.put("SizeOfExpr", SIZEOFEXPR_CODE);
        nodeTypeToCodes.put("SizeOfType", SIZEOFTYPE_CODE);
        nodeTypeToCodes.put("SizeType", SIZETYPE_CODE);
        nodeTypeToCodes.put("Some", SOME_CODE);
        nodeTypeToCodes.put("StatementExpr", STATEMENTEXPR_CODE);
        nodeTypeToCodes.put("Storage", STORAGE_CODE);
        nodeTypeToCodes.put("StructUnion", STRUCTUNION_CODE);
        nodeTypeToCodes.put("StructUnionName", STRUCTUNIONNAME_CODE);
        nodeTypeToCodes.put("Switch", SWITCH_CODE);
        nodeTypeToCodes.put("TypeName", TYPENAME_CODE);
        nodeTypeToCodes.put("TypeQualifier", TYPEQUALIFIER_CODE);
        nodeTypeToCodes.put("UnSigned", UNSIGNED_CODE);
        nodeTypeToCodes.put("Unary", UNARY_CODE);
        nodeTypeToCodes.put("While", WHILE_CODE);
        nodeTypeToCodes.put("argument", ARGUMENT_CODE);
        nodeTypeToCodes.put("argument_list", ARGUMENT_LIST_CODE);
        nodeTypeToCodes.put("block", BLOCK_CODE);
        nodeTypeToCodes.put("block_content", BLOCK_CONTENT_CODE);
        nodeTypeToCodes.put("call", FUNCALL_CODE);
        nodeTypeToCodes.put("case", CASE_CODE);
        nodeTypeToCodes.put("condition", CONDITION_CODE);
        nodeTypeToCodes.put("control", CONTROL_CODE);
        nodeTypeToCodes.put("decl", DECL_CODE);
        nodeTypeToCodes.put("decl_stmt", DECL_STMT_CODE);
        nodeTypeToCodes.put("define", DEFINE_CODE);
        nodeTypeToCodes.put("directive", DIRECTIVE_CODE);
        nodeTypeToCodes.put("elif", ELIF_CODE);
        nodeTypeToCodes.put("else", ELSE_CODE);
        nodeTypeToCodes.put("empty_stmt", EMPTY_STMT_CODE);
        nodeTypeToCodes.put("endif", ENDIF_CODE);
        nodeTypeToCodes.put("enum", ENUM_CODE);
        nodeTypeToCodes.put("error", ERROR_CODE);
        nodeTypeToCodes.put("expr", EXPR_CODE);
        nodeTypeToCodes.put("expr_stmt", EXPR_STMT_CODE);
        nodeTypeToCodes.put("file", FILE_CODE);
        nodeTypeToCodes.put("for", FOR_CODE);
        nodeTypeToCodes.put("function", FUNCTION_CODE);
        nodeTypeToCodes.put("function_decl", FUNCTION_DECL_CODE);
        nodeTypeToCodes.put("goto", GOTO_CODE);
        nodeTypeToCodes.put("if", IF_CODE);
        nodeTypeToCodes.put("if_stmt", IF_STMT_CODE);
        nodeTypeToCodes.put("ifdef", IFDEF_CODE);
        nodeTypeToCodes.put("ifndef", IFNDEF_CODE);
        nodeTypeToCodes.put("include", INCLUDE_CODE);
        nodeTypeToCodes.put("incr", INCR_CODE);
        nodeTypeToCodes.put("index", INDEX_CODE);
        nodeTypeToCodes.put("init", INIT_CODE);
        nodeTypeToCodes.put("label", LABEL_CODE);
        nodeTypeToCodes.put("literal", LITERAL_CODE);
        nodeTypeToCodes.put("macro", MACRO_CODE);
        nodeTypeToCodes.put("modifier", MODIFIER_CODE);
        nodeTypeToCodes.put("name", NAME_CODE);
        nodeTypeToCodes.put("namespace", NAMESPACE_CODE);
        nodeTypeToCodes.put("operator", OPERATOR_CODE);
        nodeTypeToCodes.put("parameter", PARAMETER_CODE);
        nodeTypeToCodes.put("parameter_list", PARAMLIST_CODE);
        nodeTypeToCodes.put("return", RETURN_CODE);
        nodeTypeToCodes.put("specifier", SPECIFIER_CODE);
        nodeTypeToCodes.put("struct", STRUCT_CODE);
        nodeTypeToCodes.put("struct_decl", STRUCT_DECL_CODE);
        nodeTypeToCodes.put("ternary", TERNARY_CODE);
        nodeTypeToCodes.put("then", THEN_CODE);
        nodeTypeToCodes.put("type", TYPE_CODE);
        nodeTypeToCodes.put("typedef", TYPEDEF_CODE);
        nodeTypeToCodes.put("undef", UNDEF_CODE);
        nodeTypeToCodes.put("union", UNION_CODE);
        nodeTypeToCodes.put("unit", UNIT_CODE);
        nodeTypeToCodes.put("using", USING_CODE);
        nodeTypeToCodes.put("value", VALUE_CODE);
    }
    private static final Map<String, Integer> actionTypeCodes = new HashMap<String, Integer>();

    static {
        actionTypeCodes.put("insert-node", INSERT_NODE);
        actionTypeCodes.put("insert-tree", INSERT_TREE);
        actionTypeCodes.put("delete-node", DELETE_NODE);
        actionTypeCodes.put("delete-tree", DELETE_TREE);
        actionTypeCodes.put("update-node", UPDATE_NODE);
        actionTypeCodes.put("update-tree", UPDATE_TREE);
        actionTypeCodes.put("move-node", MOVE_NODE);
        actionTypeCodes.put("move-tree", MOVE_TREE);
        // ...
    }

    public void setExpensiveMatching(boolean expensiveMatching) {
        this.expensiveMatching = expensiveMatching;
    }

    DiffObtainer(String output) throws IOException {
        this.output = output;
        Path path = Paths.get(output);
        Files.createDirectories(path.getParent());
    }
    DiffObtainer() {
    }
    /**
     * Method used to get changes between two files and output them in the file
     * whose path is stored in the member variable output
     * @param file1
     * @param file2
     * @param analysis
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        String outputPath = args[0];
        String project = args[1];
        String commit = args[2];
        String prev = args[3];
        String dirPath = args[4];
        String[] files = args[5].split(";");

        List<String[]> pairs = new ArrayList():
        for (String file: files){
            String[] pair = {dirpath + "/" + prev + "/" + file,
                            dirpath + "/" + commit + "/" + file};
            pairs.add(pair); 
        }

        String gumtreeOutput = outputPath + "/" + project + "/" + cve + "/gumtree_output.txt";
        DiffObtainer diffObtainer = new DiffObtainer(gumtreeOutput);
        diffObtainer.setExpensiveMatching(true);
        String callGraphOutput = outputPath + "/" + project + "/" + cve + "/gumtree_callgraph.txt";
        diffObtainer.actionCleaningNeeded = true;
        diffObtainer.setProject(project);
        diffObtainer.getDiffPerFunctionInCommit(pairs);
    }

    /**
     * Method used to get the diffs per each function in commit and write the
     * results in a file
     * @param files
     * @throws IOException
     */
     getDiffPerFunctionInCommit(List<String[]> files) throws IOException {
        pw = new PrintWriter(new FileWriter(new File(output), true));
        HashMap<String, List<Action>> functionToActions = new HashMap<>();
        for(String[] pair: files){
            String file1 = pair[0];
            String file2 = pair[1];
            List<Action> actions = getDiffPerPair(file1, file2);
            if (deletedPair) {
                gatherFunctions(functionToActions, actions, file1);
            }
            else {
                gatherFunctions(functionToActions, actions, file2);
            }

            if (deletedPair) {
                gatherLines(functionToActions, actions, file1);
            }
            else {
                gatherLines(functionToActions, actions, file2);
            }
        }
        // We run the analysis before we consolidate the actions
        if (analyzeCallGraph){
            analyzeCallGraphChanges(functionToActions);
        }

        HashMap<String, List<String>> stringListHashMap = stringifyActions(functionToActions);
        writeFunctions(stringListHashMap);
    }


     private List<Action> getActionsPerInsertedOrDeletedFile(String file, String type) throws IOException {
        LineReader lineReader = new LineReader(new BufferedReader(new FileReader(file)));

        Tree t;
        if(file.endsWith(".cpp")){
            t = new SrcmlCppTreeGenerator().generate(lineReader).getRoot();
            language = "CPP";
            filetoLanguage.put(file, language);
        }
        else if (file.endsWith(".h") || file.endsWith(".hh")) {
            t = new SrcmlCTreeGenerator().generate(lineReader).getRoot();
            language = "H";
            filetoLanguage.put(file, language);
        }
        else {
            if (bestGeneratorForC(file).equalsIgnoreCase("SRCML")) {
                t = new SrcmlCTreeGenerator().generate(lineReader).getRoot();
                language = "CPP";
                filetoLanguage.put(file, language);
            }
            else {
                t = new CTreeGenerator().generate(lineReader).getRoot();
                language = "C";
                filetoLanguage.put(file, language);
            }
        }
        Iterator<Tree> iterator = t.breadthFirst().iterator();
        List<Action> actions = new ArrayList<>();
        while(iterator.hasNext()){
            Tree tree = iterator.next();
            if (!tree.isRoot() && !tree.getType().name.equalsIgnoreCase("comment")) {
                Action action;
                if (type.equalsIgnoreCase("insert")) {
                    action = new Insert(tree, tree.getParent(), tree.positionInParent());
                }
                else {
                    action = new Delete(tree);
                }
                actions.add(action);
            } else {
                // fake action for root
                Action action;
                if (type.equalsIgnoreCase("insert")) {
                    action = new Insert(tree, tree, 0);
                }
                else {
                    action = new Delete(tree);
                }
                actions.add(action);
            }
        }
        return actions;
    }


    /**
     * Function to get the changes in form of Action in gumtree speak between two files
     * @param file1
     * @param file2
     * @return
     * @throws IOException
     */
     List<Action> getActions(String file1, String file2) throws IOException {
        Run.initGenerators();
        System.out.println("Diff Generators created.");
        Option.Verbose.verbose = true;

        Run.initGenerators(); // registers the available parsers
        File filePath1 = new File(file1);
        File filePath2 = new File(file2);
        if (filePath1.exists() && filePath1.isFile() && !filePath2.exists() && !filePath2.isFile()){
            actionCleaningNeeded = false;
            deletedPair = true;
            return getActionsPerInsertedOrDeletedFile(file1, "delete");
        }
        else if(filePath2.exists() && filePath2.isFile() && !filePath1.exists() && !filePath1.isFile()) {
            actionCleaningNeeded = false;
            deletedPair = false;
            return getActionsPerInsertedOrDeletedFile(file2, "insert");
        }
        deletedPair = false;
        actionCleaningNeeded = true;
        l1 = new LineReader(new BufferedReader(new FileReader(file1)));
        Tree t1;
        String bestGeneratorForCFile1 = "";
        if(file1.endsWith(".cpp") || file1.endsWith(".hh") || file1.endsWith(".cc")){
            t1 = new SrcmlCppTreeGenerator().generate(l1).getRoot();
            language = "CPP";
            filetoLanguage.put(file1, language);
            filetoLanguage.put(file2, language);
        }
        else if (file1.endsWith(".h") ) {
            t1 = new SrcmlCTreeGenerator().generate(l1).getRoot();
            language = "H";
            filetoLanguage.put(file1, language);
            filetoLanguage.put(file2, language);
        }
        else {
            bestGeneratorForCFile1 =  bestGeneratorForC(file1);
            if (bestGeneratorForCFile1.equalsIgnoreCase("SRCML")) {
                t1 = new SrcmlCTreeGenerator().generate(l1).getRoot();
                language = "CPP";
                filetoLanguage.put(file1, language);
                filetoLanguage.put(file2, language);
            }
            else {
                t1 = new CTreeGenerator().generate(l1).getRoot();
                language = "C";
                filetoLanguage.put(file1, language);
                filetoLanguage.put(file2, language);
            }
        }

        l2 = new LineReader(new BufferedReader(new FileReader(file2)));

        fileToRoot.put(file1, t1);

        Tree t2;
        if(file2.endsWith(".cpp") || file2.endsWith(".cc") || file2.endsWith(".hh")){
            t2 = new SrcmlCppTreeGenerator().generate(l2).getRoot();

        }
        else if (file2.endsWith(".h")) {
            t2 = new SrcmlCTreeGenerator().generate(l2).getRoot();

        }
        else{
            if (bestGeneratorForCFile1.equalsIgnoreCase("SRCML")) {
                t2 = new SrcmlCTreeGenerator().generate(l2).getRoot();
            }
            else {
                t2 = new CTreeGenerator().generate(l2).getRoot();
            }
        }
        fileToRoot.put(file2, t2);

        setLanguage(file1);
        MappingStore m;

        if (expensiveMatching) {
            try {
                m = Matchers.getInstance().getMatcher("classic-gumtree-theta").match(t1, t2);
            }
            catch (OutOfMemoryError oue){
                m = Matchers.getInstance().getMatcher().match(t1, t2);
            }
        }
        else {
            m = Matchers.getInstance().getMatcher().match(t1, t2);
        }

        fileToMappingStore.put(file1, m);
        fileToMappingStore.put(file2, m);

        EditScriptGenerator editScriptGenerator = new SimplifiedChawatheScriptGenerator();
        return editScriptGenerator.computeActions(m).asList();
    }

     String bestGeneratorForC(String file) throws IOException {
        Tree cTree = new CTreeGenerator().generate(new LineReader(new BufferedReader(new FileReader(file)))).getRoot();
        int cNotParsedCorrectlyOccurrences = subsrting_rec(cTree.toTreeString(), "NotParsedCorrectly");

        Tree srcTree = new SrcmlCTreeGenerator().generate(new LineReader(new BufferedReader(new FileReader(file)))).getRoot();
        int srcNotParsedCorrectlyOccurrences = subsrting_rec(srcTree.toTreeString(), "NotParsedCorrectly");

        return cNotParsedCorrectlyOccurrences >= srcNotParsedCorrectlyOccurrences ? "SRCML" : "C";

    }

    private void setLanguage(String file1){
        language = filetoLanguage.get(file1);
    }


    private void cleanListOfActions(List<Action> actions){
        System.out.println("Cleaning list of actions");
        outter:
        for(int i=0; i < actions.size(); i++){
            Action action1 = actions.get(i);
            if (action1.getNode().getType().name.equalsIgnoreCase("comment")){
                actions.remove(i);
                i--;
                continue;
            }
            for(int j=i+1; j<actions.size(); j++){
                Action action2 = actions.get(j);
                if(areOpposite(action1, action2)){
                    actions.remove(i);
                    actions.remove(j-1);
                    i--;
                    continue outter;
                }
            }
        }
        consolidateParameterActionsPerLine(actions);
        removeNotParsedCorrectly(actions);

//        if (expensiveMatching) {
//            areUpdate(actions);
//        }
    }

    private void areUpdate(List<Action> actions){
        outter:
        for(int i=0; i < actions.size(); i++){
            Action action1 = actions.get(i);
            for(int j=i+1; j<actions.size(); j++){
                Action action2 = actions.get(j);
                if(areOppositeActionTypes(action1.getName(), action2.getName())){
                    Tree node1 = action1.getNode();
                    Tree node2 = action2.getNode();

                    if (node1.isIsoStructuralTo(node2)){

                        Action initial;
                        Action changed;

                        if (action1.getName().contains("delete")){
                            initial = action1;
                            changed = action2;
                        } else {
                            initial = action2;
                            changed = action1;
                        }
                        String oldName = getStringDifferenceBetweenActions(changed, initial);
                        String newName = getStringDifferenceBetweenActions(initial, changed);
                        Tree initialNode = initial.getNode();
                        Iterator<Tree> iterator = initialNode.breadthFirst().iterator();
                        while(iterator.hasNext()){
                            Tree tree = iterator.next();
                            if (tree.hasLabel() && tree.getLabel().equalsIgnoreCase(oldName)){
                                Update action = new Update(tree, newName);
                                actions.remove(i);
                                actions.remove(j-1);
                                System.out.println("Deleted " + sanitizeAction(action1.toString()));
                                System.out.println("Deleted " + sanitizeAction(action2.toString()));
                                actions.add(action);
                                i--;
                                continue outter;
                            }
                        }
                    }

                    else {
                        Action initial;
                        Action changed;

                        if (action1.getName().contains("delete")){
                            initial = action1;
                            changed = action2;
                        } else {
                            initial = action2;
                            changed = action1;
                        }
                        List<Tree> firstDescendants = initial.getNode().getDescendants();
                        List<Tree> secondDescendants = changed.getNode().getDescendants();
                        List<Integer> firstIndicesMatched = new ArrayList<>();
                        List<Integer> secondIndicesMatched = new ArrayList<>();

                        outer:
                        for (int ii =0; ii< firstDescendants.size(); ii++ ){
                            if (firstIndicesMatched.contains(ii)){
                                continue;
                            }
                            Tree firstDescendant = firstDescendants.get(ii);
                            for (int jj=0; jj < secondDescendants.size(); jj++){
                                Tree secondDescendant = secondDescendants.get(jj);
                                if (secondIndicesMatched.contains(jj)){
                                    continue;
                                }
                                if (firstDescendant.isIsomorphicTo(secondDescendant)){
                                    firstIndicesMatched.add(ii);
                                    secondIndicesMatched.add(jj);
                                    continue outer;
                                }
                            }
                        }

                        List<Tree> unmatchedFirst = new ArrayList<>();
                        for (int ii =0; ii<firstDescendants.size(); ii++){
                            Tree tree = firstDescendants.get(ii);
                            if (!firstIndicesMatched.contains(ii)){
                                unmatchedFirst.add(tree);
                            }
                        }

                        List<Tree> unmatchedSecond = new ArrayList<>();
                        for (int ii =0; ii<secondDescendants.size(); ii++){
                            Tree tree = secondDescendants.get(ii);
                            if (!secondIndicesMatched.contains(ii)){
                                unmatchedSecond.add(tree);
                            }
                        }


                        for(Tree first: unmatchedFirst){
                            String differences = "";
                            for (Tree second: unmatchedSecond){
                                if (first.isIsoStructuralTo(second)){
                                    String newName = getStringDifferenceBetweenActions(initial, changed);
                                    differences += newName + " ";
                                }
                            }

                            if (differences.trim().length() > 0) {
                                Update action = new Update(initial.getNode(), differences);
                                actions.remove(i);
                                actions.remove(j-1);
                                actions.add(action);
                                i--;
                                continue outter;
                            }
                        }
                    }
                }
            }
        }
    }

    private String getStringDifferenceBetweenActions(Action action1, Action action2){
        String sanitizedAction1toString = sanitizeAction(action1.toString()).replaceAll("insert", "").
                replaceAll("delete", "");
        if (action2.getName().contains("insert")){
            int i = sanitizedAction1toString.indexOf(" to ");
            if (i>0){
                sanitizedAction1toString = sanitizedAction1toString.substring(0, i);
            }
        }

        String sanitizedAction2toString = sanitizeAction(action2.toString()).replaceAll("insert", "").
                replaceAll("delete", "");
        if (action2.getName().contains("insert")){
            int i = sanitizedAction2toString.indexOf(" to ");
            if (i>0){
                sanitizedAction2toString = sanitizedAction2toString.substring(0, i);
            }
        }

        String[] differenceFrom = StringUtils.difference(sanitizedAction1toString, sanitizedAction2toString).split(" ");
        String finalResult = "";
        for (String word: differenceFrom){
            if (!sanitizedAction1toString.contains(word)){
                finalResult += word + "\n";
            }
        }

        return finalResult.trim();
    }
    private boolean areOppositeActionTypes(String action1, String action2 ){
        List<String> types = new ArrayList<>();
        types.add(action1);
        types.add(action2);
        return (types.contains("insert-tree") && types.contains("delete-tree")) ||
                (types.contains("insert-node") && types.contains("delete-node"));
    }
    private void removeNotParsedCorrectly(List<Action> actions){
        for (int i=0; i<actions.size(); i++){
            Action action = actions.get(i);
            if (action.getNode().getType().name.equalsIgnoreCase("NotParsedCorrectly")){
                actions.remove(i);
                i--;
            }
        }
    }

    private void consolidateParameterActionsPerLine(List<Action> actions) {
        HashMap<Integer, List<Action>> mapOfActionsPerLine = new HashMap<>();
        for (Action action: actions){
            int[] ints;
            if (action.getName().contains("delete")) {
                ints = l1.positionFor(action.getNode().getPos());
            }
            else{
                ints = l2.positionFor(action.getNode().getPos());
            }
            List<Action> actionsPerLine;
            if (mapOfActionsPerLine.containsKey(ints[0])){
                actionsPerLine = mapOfActionsPerLine.get(ints[0]);
                actionsPerLine.add(action);
            }
            else{
                actionsPerLine = new ArrayList<>();
                actionsPerLine.add(action);
            }
            mapOfActionsPerLine.put(ints[0], actionsPerLine);
        }

        Iterator<Map.Entry<Integer, List<Action>>> iterator = mapOfActionsPerLine.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<Integer, List<Action>> entry = iterator.next();
            List<Action> actionsPerLine = entry.getValue();
            List<Integer> indices = new ArrayList<>();
            List<Integer> indicesParameterType = new ArrayList<>();
            for(int i=0; i<actionsPerLine.size(); i++){
                Action action = actionsPerLine.get(i);
                if (!action.getNode().isRoot() && action.getNode().getType().name.equalsIgnoreCase("ParameterType")){
                    indicesParameterType.add(i);
                }
                if (!action.getNode().isRoot() && action.getNode().getParent().getType().name.equalsIgnoreCase("ParameterType")){
                    indices.add(i);
                }
            }
            if(indicesParameterType.size()>0){
                for(Integer i: indices) {
                    actions.remove(actionsPerLine.get(i));
                }
            }
        }
    }
    private boolean areOpposite(Action action1, Action action2){
        if(!action1.getNode().isIsomorphicTo(action2.getNode())){
            return false;
        }
        if( (action1 instanceof TreeInsert && action2 instanceof TreeDelete) ||
                (action1 instanceof TreeDelete && action2 instanceof TreeInsert)){
            return true;
        }
        return (action1 instanceof Insert && action2 instanceof Delete) ||
                (action1 instanceof Delete && action2 instanceof Insert);
    }

    private void writeToFileAnalysis(Action action) {
        pw.write("{\n");
        try{
            pw.write("action:" + action.getName() + "\n");
            pw.write("node:" + action.getNode().getType() + "\n");
            pw.write("type:" + getType(action.getNode())+"\n");
            pw.write("identifier:" + getIdentifier(action.getNode())+"\n");
            pw.write("function:" + getFunctionIdentifier(action.getNode()) + "\n"); ;
            if (action instanceof Update){
                Update update = (Update) action;
                String value = update.getValue();
                pw.write("value:" + value + "\n");
                String parentNode = update.getNode().getParent().getType().name;
                pw.write("parent-node:" + parentNode);

            }

            if (action instanceof TreeInsert){
                TreeInsert treeInsert = (TreeInsert) action;
                Tree parent = treeInsert.getParent();
                if (parent.getType().name.equals("argument_list")){
                    parent = parent.getParent();
                }

                pw.write("parent-node:" + parent.getType() +"\n");
                pw.write("parent-type:" + getType(parent)  +"\n");

                if (action.getNode().getType().name.equalsIgnoreCase("parameter") ||
                        action.getNode().getType().name.equalsIgnoreCase("argument")){
                    pw.write("position-in-list:" + getPositionInArgandParList(action.getNode()) + "\n");
                }
            }
            if (action instanceof Move){
                Move move = (Move) action;
                Tree parent = move.getParent();
                pw.write("parent-node:" + parent.getType() +"\n");
                pw.write("parent-type:" + getType(parent)  +"\n");

            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            pw.write("}\n");
        }
    }

    private boolean checkIfFuncCallIsParentNode(Tree tree){
        if (language.equalsIgnoreCase("C")){
            return checkIfFuncCallIsParentNodeForC(tree);
        }
        else {
            return checkIfFuncCallIsParentNodeForCPP(tree);
        }
    }

    private boolean checkIfFuncCallIsParentNodeForC(Tree tree){
        if(!(tree.getType().name.equalsIgnoreCase("Ident") ||
                tree.getType().name.equalsIgnoreCase("Left") ||
                tree.getType().name.equalsIgnoreCase("GenericList") ||
                tree.getType().name.equalsIgnoreCase("FunCall"))){
            return false;
        }
        while(!tree.isRoot()){
            if (tree.getType().name.equalsIgnoreCase("FunCall")){
                return true;
            }
            tree = tree.getParent();
        }

        return false;
    }

    private boolean checkIfFuncCallIsParentNodeForCPP(Tree tree){
        if(!(
                tree.getType().name.equalsIgnoreCase("argument") ||
                tree.getType().name.equalsIgnoreCase("argument_list") ||
                tree.getType().name.equalsIgnoreCase("call"))){
            return false;
        }
        while(!tree.isRoot()){
            if (tree.getType().name.equalsIgnoreCase("call")){
                return true;
            }
            tree = tree.getParent();
        }

        return false;
    }

    String[] values(String oldLine, String newLine){
        String oldValue = oldLine.split("\\$\\(value")[1];
        oldValue = oldValue.substring(0, oldValue.length()-3);

        String newValue = newLine.split("\\$\\(value")[1];
        newValue = newValue.substring(0, newValue.length()-3);

        return new String[]{oldValue, newValue};
    }
    private String funCallIdentifier(Tree tree){
        if (language.equalsIgnoreCase("C")){
            return funCallIdentifierForC(tree);
        }

        if (language.equalsIgnoreCase("CPP") || language.equalsIgnoreCase("H")){
            return funCallIdentifierForCPP(tree);
        }

        return "N/A";
    }

    private String funCallIdentifierForC(Tree tree){
        while(!tree.isRoot()){
            if(tree.getType().name.equalsIgnoreCase("FunCall") && !tree.isLeaf()){
                for(Tree child: tree.getChildren()){
                    if(child.getType().name.equalsIgnoreCase("Ident")){
                        for(Tree grandChild: child.getChildren()) {
                            if(grandChild.getType().name.equalsIgnoreCase("GenericString")){
                                return grandChild.getLabel();
                            }
                        }
                    }
                }
            }
            tree = tree.getParent();
        }
        return "N/A";
    }

    private String funCallIdentifierForCPP(Tree tree){

        while(!tree.isRoot()){
            if(tree.getType().name.equalsIgnoreCase("call") && !tree.isLeaf()){
                for(Tree child: tree.getChildren()){
                    if(child.getType().name.equalsIgnoreCase("name")){
                       return child.getLabel();
                    }
                }
            }
            tree = tree.getParent();
        }
        return "N/A";
    }
    private void writeToFile(Action action) {
        int[] ints;
        if (action.getName().contains("delete")) {
            ints = l1.positionFor(action.getNode().getPos());
        }
        else{
            ints = l2.positionFor(action.getNode().getPos());
        }
        pw.write("{\n");
        try {
            String functionName = "";
            pw.write("action:" + action.getName() + "\n");
            pw.write("node:" + action.getNode().getType() + "\n");
            pw.write("type:" + getType(action.getNode()) + "\n");
            pw.write("identifier:" + getIdentifier(action.getNode()) + "\n");
            pw.write("position:" + ints[0] + "\n");

            String parentNode = "";
            String parentIdentifier = "";
            boolean isFuncCall = checkIfFuncCallIsParentNode(action.getNode().getParent()) ||
                    checkIfFuncCallIsParentNode(action.getNode());

            if (action instanceof Update) {
                Update update = (Update) action;
                String value = update.getValue();
                pw.write("value:" + value + "\n");
                if (!parentNode.equalsIgnoreCase("FunCall"))
                    parentNode = update.getNode().getParent().getType().name;
                if (update.getNode().getType().name.equals("GenericString") && !update.getNode().isRoot() &&
                        isCFunction(action.getNode().getParent())) {
                    functionName = update.getValue();
                }

            }

            if (action instanceof TreeInsert) {
                TreeInsert treeInsert = (TreeInsert) action;
                Tree parent = treeInsert.getParent();
                if (parent.getType().name.equals("argument_list")) {
                    parent = parent.getParent();
                }

                pw.write("parent-type:" + getType(parent) + "\n");
                parentIdentifier = getIdentifier(parent);
                if (isFuncCall){
                    parentIdentifier = funCallIdentifier(action.getNode());
                }
                pw.write("parent-position:" + l2.positionFor(parent.getPos())[0] + "\n");
                pw.write("parent-function:" + getFunctionIdentifier(parent) + "\n");

                if (!parentNode.equalsIgnoreCase("FunCall")) {
                    parentNode = parent.getType().name;
                }
            }

            if (action instanceof Move) {
                Move move = (Move) action;
                Tree parent = move.getParent();
                parentIdentifier = getIdentifier(parent);
                if (!parentNode.equalsIgnoreCase("FunCall")) {
                    parentNode = parent.getType().name;
                    parentIdentifier = funCallIdentifier(action.getNode());
                }

                pw.write("parent-type:" + getType(parent) + "\n");
                pw.write("parent-position:" + l2.positionFor(parent.getPos())[0] + "\n");
                pw.write("parent-function:" + getFunctionIdentifier(parent) + "\n");
                ;
            }
            if (action.getNode().getType().name.equalsIgnoreCase("parameter") ||
                    action.getNode().getType().name.equalsIgnoreCase("argument") ||
                    action.getNode().getType().name.equalsIgnoreCase("ParameterType")) {
                pw.write("position-in-list:" + getPositionInArgandParList(action.getNode()) + "\n");
            }

            if (functionName.equalsIgnoreCase("")) {
                functionName = getFunctionIdentifier(action.getNode());
            }
            if (isFuncCall) {
                parentNode = "FunCall";
                pw.write("position-in-list:" + getPositionInArgandParList(action.getNode()) + "\n");
                if (parentIdentifier.equalsIgnoreCase("")) {
                    parentIdentifier =
                            funCallIdentifier(action.getNode());
                }
            }
            if (!parentNode.equalsIgnoreCase("")) {
                pw.write("parent-node:" + parentNode + "\n");
            }
            if (!parentNode.equalsIgnoreCase("")){
                pw.write("parent-identifier:" + parentIdentifier + "\n");
           }

            pw.write("function:" + functionName + "\n");
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally {
            pw.write("}\n");
        }
    }

    public int countFunctions(String filePath) throws IOException, XMLStreamException {
        int count = 0;
        Run.initGenerators();
        Tree t;
        l1 = new LineReader(new BufferedReader(new FileReader(filePath)));
        try {
            if (filePath.endsWith(".cpp")) {
                t = new SrcmlCppTreeGenerator().generate(l1).getRoot();
                Iterator<Tree> trees = t.breadthFirst().iterator();
                while (trees.hasNext()) {
                    Tree tree = trees.next();
                    if (tree.getType().name.equalsIgnoreCase("function")) {
                        count++;
                    }
                }
            } else {
                t = new CTreeGenerator().generate(l1).getRoot();
                Iterator<Tree> trees = t.breadthFirst().iterator();
                while (trees.hasNext()) {
                    Tree tree = trees.next();
                    if (isCFunction(tree)) {
                        count++;
                    }
                }
            }
        }
        finally {
            return count;
        }

    }

    private boolean isCFunction(Tree tree){
        if(!tree.getType().name.equalsIgnoreCase("Definition")){
            return false;
        }
        if (tree.isLeaf()){
            return false;
        }
        List<Tree> children = tree.getChildren();
        boolean hasParamList = false;
        boolean hasGenericString = false;
        boolean hasCompound = false;
        for (Tree child: children){
            if(!hasParamList){
                hasParamList = child.getType().name.equalsIgnoreCase("ParamList");
            }
            if(!hasGenericString){
                hasGenericString = child.getType().name.equalsIgnoreCase("GenericString");
            }
            if(!hasCompound){
                hasCompound = child.getType().name.equalsIgnoreCase("Compound");
            }
        }
        return hasParamList && hasGenericString && hasCompound;
    }


    private String getType(Tree tree){
        Iterator<Tree> iterator = tree.breadthFirst().iterator();
        while(iterator.hasNext()){
            Tree next = iterator.next();
            if(next.getType().name.equalsIgnoreCase("type") && next.getChildren().size()>0 &&
                    next.getChild(0).getType().name.equalsIgnoreCase("name")
                    && (next.getChildren().size()>1 && next.getChild(1).getType().name.equalsIgnoreCase("modifier"))){

                return next.getChild(0).getLabel()+ "-pointer";
            }
            if(next.getType().name.equalsIgnoreCase("type") && next.getChildren().size()>0 && next.getChild(0).getType().name.equalsIgnoreCase("name")){
                return next.getChild(0).getLabel();
            }
        }
        return null;
    }

    private String getIdentifier(Tree tree){
        Iterator<Tree> iterator = tree.breadthFirst().iterator();
        while(iterator.hasNext()){
            Tree next = iterator.next();
            if(next.getType().name.equalsIgnoreCase("name")){
                return next.getLabel();
            }
            if(next.getType().name.equalsIgnoreCase("literal")){
                return next.getLabel();
            }
            if(next.getType().name.equalsIgnoreCase("GenericString")){
                return next.getLabel();
            }
            if(next.getType().name.equalsIgnoreCase("operator")){
                return next.getLabel();
            }
        }

        return null;
    }

    private int getPositionInArgandParList(Tree child){
        Tree parent = child.getParent();
        int i = -1;
        for (Tree potChild: parent.getChildren()){
            if (potChild.isIsomorphicTo(child)){
                return ++i;
            }
            i++;
        }
        return i;
    }

    private String getFunctionIdentifier(Tree tree){
        if (language.equalsIgnoreCase("C")){
            return getFunctionIdentifierForC(tree);
        }
        else if (language.equalsIgnoreCase("CPP")){
            return getFunctionIdentifierForCPP(tree);
        }
        // need tests to see how cpp header files work
        else{
            return getFunctionIdentifierForH(tree);
        }
    }

    private Tree getFunction(Tree tree){
        if (language.equalsIgnoreCase("C")){
            return getFunctionForC(tree);
        }
        else if (language.equalsIgnoreCase("CPP")){
            return getFunctionForCPP(tree);
        }
        // need tests to see how cpp header files work
        else{
            return getFunctionForH(tree);
        }
    }
    private String getFunctionIdentifierForC(Tree tree){
        Tree function = getFunctionForC(tree);
        if (function == null) {
            return "GLOBAL";
        }
        return getIdentifier(function);
    }

    private Tree getFunctionForC(Tree tree){
        while(!tree.isRoot()){
            if (tree.getType().name.equalsIgnoreCase("Definition")){
                return tree;
            }
            tree = tree.getParent();
        }
        return null;
    }
    private String getFunctionIdentifierForCPP(Tree tree){
        Tree function = getFunctionForCPP(tree);
        if (function == null) {
            return "GLOBAL";
        }
        List<Tree> children = function.getChildren();
        String name = "";
        // a bit of a hack for 2da0d70
        for (Tree child: children){
            if (child.getType().name.equalsIgnoreCase("type") && !child.isLeaf()){
                List<Tree> grandChildren = child.getChildren();
                if (grandChildren.size() >=4) {
                    Tree last = grandChildren.get(grandChildren.size() - 1);
                    if (last.getType().name.equalsIgnoreCase("name") && last.hasLabel()) {
                        name += last.getLabel();
                    }
                }
            }
            if (!name.equalsIgnoreCase("") && child.getType().name.equalsIgnoreCase("name") && child.hasLabel()){
                name += "(" + child.getLabel() + ")";
            }
        }
        if (name.equalsIgnoreCase("")) {
            return getIdentifier(function);
        }
        return name;
    }
    boolean hasChildWithType(Tree tree, String type){
         if (tree.isLeaf()){
             return false;
         }
         List<Tree> children = tree.getChildren();
         for (Tree child : children){
             if (child.getType().name.equalsIgnoreCase(type)){
                 return true;
             }
        }
        return false;
    }
    private Tree getFunctionForCPP(Tree tree){
        while(!tree.isRoot()){
            if (tree.getType().name.equalsIgnoreCase("function") ||
                    tree.getType().name.equalsIgnoreCase("function_decl") ||
                    (tree.getType().name.equalsIgnoreCase("struct") && hasChildWithType(tree, "name"))){
                return tree;
            }
            tree = tree.getParent();
        }
        return null;
    }
    private String getFunctionIdentifierForH(Tree tree){
        Tree function = getFunctionForH(tree);
        Tree originalTree = tree;
        if (function == null){
            return "GLOBAL";
        }

        if (function.getType().name.equalsIgnoreCase("define")){
            for (Tree child: function.getChildren()){
                if (child.getType().name.equalsIgnoreCase("macro")){
                    for( Tree grandChild : child.getChildren()){
                        if (grandChild.getType().name.equalsIgnoreCase("name")){
                            return grandChild.getLabel();
                        }
                    }
                }
            }
        }
        if (function.getType().name.equalsIgnoreCase("struct")){
            for (Tree child: function.getChildren()){
                if (child.getType().name.equals("name")){
                    return child.getLabel();
                }
            }
        }

        return getFunctionIdentifierForCPP(originalTree);
    }
    private Tree getFunctionForH(Tree tree){
        Tree originalTree = tree;
        while(!tree.isRoot()){
            if (tree.getType().name.equalsIgnoreCase("define")){
                for (Tree child: tree.getChildren()){
                    if (child.getType().name.equalsIgnoreCase("macro")){
                        for( Tree grandChild : child.getChildren()){
                            if (grandChild.getType().name.equalsIgnoreCase("name")){
                                return tree;
                            }
                        }
                    }
                }
            }
            if (tree.getType().name.equalsIgnoreCase("struct")){
                return tree;
            }

            tree = tree.getParent();
        }
        tree = getFunctionForCPP(originalTree);
        return tree;
    }

    String encodeStringifiedFunction(String function, Action action){
        String[] divided = function.split(" ");
        String result = "";
        int i = 0;
        for (String word: divided){
            if (word.equalsIgnoreCase("===") || word.equalsIgnoreCase("") ||
            word.equalsIgnoreCase("[]") || word.equalsIgnoreCase("---")){
                continue;
            }
            if(actionTypeCodes.containsKey(word) && i==0){
                result += actionTypeCodes.get(word)+ " ";
                i++;
            }
            else if (nodeTypeToCodes.containsKey(word) && (action.getNode().getType().name.equalsIgnoreCase(word) ||
                    (!action.getNode().isRoot() && action.getNode().getParent().getType().name.equalsIgnoreCase(word)))){
                result += nodeTypeToCodes.get(word) + " ";
                i++;
            }
            else {
                result += word.hashCode() + " ";
                i++;
            }
        }
        return result.trim();
    }

    /**
     * Function to write actions per function in string form
     * @param functionToActions
     */
    HashMap<String, List<String>> stringifyActions(HashMap<String, List<Action>> functionToActions){
        Iterator<Map.Entry<String, List<Action>>> iterator = functionToActions.entrySet().iterator();
        HashMap<String, List<String>> functionToSummarizedActionList = new HashMap<>();
        while (iterator.hasNext()){
            Map.Entry<String, List<Action>> next = iterator.next();
            String function = next.getKey();
            List<Action> actions = next.getValue();
            HashMap<Action, String> summarizedActions = new HashMap<>();
            summarizeActionsPerType(summarizedActions, actions, "insert");
            summarizeActionsPerType(summarizedActions, actions, "delete");
            summarizeActionsPerType(summarizedActions, actions, "update");
            for (Action action: actions){
                String stringifiedAction;
                if (summarizedActions.containsKey(action)){
                    stringifiedAction = sanitizeAction(summarizedActions.get(action));
                }
                else {
                    stringifiedAction = sanitizeAction(action.toString());
                }
                String finalResult = encodeStringifiedFunction(stringifiedAction, action);
                if (functionToSummarizedActionList.containsKey(function)){
                    List<String> summarizedActionList = functionToSummarizedActionList.get(function);
                   // if (!summarizedActionList.contains(stringifiedAction)) {
                        summarizedActionList.add(finalResult);
                    //}
                    functionToSummarizedActionList.replace(function, summarizedActionList);
                } else {
                    List<String> summarizedActionList = new ArrayList<>();
                    summarizedActionList.add(finalResult);
                    functionToSummarizedActionList.put(function, summarizedActionList);
                }
            }
        }
        return functionToSummarizedActionList;
    }

    /**
     * We summarize actions per insert
     * @param actions
     * @param actionType
     * @return
     */
    void summarizeActionsPerType(HashMap<Action, String> summarizedActions, List<Action> actions, String actionType){
        System.out.println("summarizing actions per type "  + actionType);
        HashMap<Tree, Pair<Tree, Integer>> nodeGraphForwardDirection = new HashMap<>();
        HashMap<Tree, Action> nodeToAction = new HashMap<>();
        for (Action action: actions){
            if (action.getName().contains(actionType)){
                nodeGraphForwardDirection.put(action.getNode(), null);
                nodeToAction.put(action.getNode(), action);
            }
        }
        for (Action action: actions){
            if (action.getName().contains(actionType)){
                if(!action.getNode().isRoot() && nodeGraphForwardDirection.containsKey(action.getNode().getParent())){
                    Pair<Tree, Integer> pair = getTreePositionPair(action);
                    nodeGraphForwardDirection.put(action.getNode(), pair);
                }
            }
        }
        List<Tree> leaves = new ArrayList<>();
        for (Tree tree: nodeGraphForwardDirection.keySet()) {
            Iterator<Map.Entry<Tree, Pair<Tree, Integer>>> iterator = nodeGraphForwardDirection.entrySet().iterator();
            boolean match = false;
            while (iterator.hasNext()) {
                Map.Entry<Tree, Pair<Tree, Integer>> next = iterator.next();
                Pair<Tree, Integer> value = next.getValue();
                if (value == null){
                    continue;
                }
                Tree first = value.first;
                if (first.equals(tree)){
                    match = true;
                    break;
                }
            }
            if (!match){
                leaves.add(tree);
            }
        }
        System.out.println("built a graph");
        HashMap<Tree, List<Pair<Tree, Integer>>> treeListHashMap = BFSUtil(nodeGraphForwardDirection, leaves);
        generateSummary(summarizedActions, treeListHashMap, nodeToAction, actions);
    }

    void generateSummary(HashMap<Action, String> summarizedActions, HashMap<Tree, List<Pair<Tree, Integer>>> treeListHashMap,
                                            HashMap<Tree, Action> treeToActionMap,
                                            List<Action> actions){
        System.out.println("generating a summary");
        Iterator<Map.Entry<Tree, List<Pair<Tree, Integer>>>> iterator = treeListHashMap.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<Tree, List<Pair<Tree, Integer>>> next = iterator.next();
            Tree key = next.getKey();
            Action mainAction = treeToActionMap.get(key);
            List<Pair<Tree, Integer>> values = next.getValue();
            if (values.size()>1){
                String summary = mainAction.getName() + " ";
                if (mainAction.getName().equals("insert-tree")){
                    summary += key.toTreeString();
                }
                else {
                    summary += key.toString();
                }
                for (Pair<Tree, Integer> value: values){
                    Tree tree = value.first;
                    Action action = treeToActionMap.get(tree);
                    if (action.getName().equals("insert-tree")){
                        summary += tree.toTreeString() + " ";
                    }
                    else {
                        summary += tree.toString() + " ";
                    }
                    actions.remove(action);
                }
                summarizedActions.put(mainAction, summary.trim());
            }
        }
        System.out.println("summary generated");

    }

    HashMap<Tree, List<Pair<Tree, Integer>>> BFSUtil(HashMap<Tree, Pair<Tree, Integer>> nodeGraph, List<Tree> toVisit){
        HashMap<Tree, List<Pair<Tree, Integer>>> consolidatedActions = new HashMap<>();

        for (int i=0; i<toVisit.size(); i++) {
            Tree tree = toVisit.get(i);
            Pair<Tree, Integer> parentTreeIntegerPair = nodeGraph.get(tree);
            if (parentTreeIntegerPair != null) {
                Tree parentTree = parentTreeIntegerPair.first;
                List<Pair<Tree, Integer>> trees;
                if (consolidatedActions.containsKey(parentTree)) {
                    trees = consolidatedActions.get(parentTree);
                } else {
                    trees = new ArrayList<>();
                }
                Pair<Tree, Integer> treeIntegerPair = new Pair<>(tree, parentTreeIntegerPair.second);
                trees.add(treeIntegerPair);
                if(consolidatedActions.containsKey(tree)){
                    for(Pair<Tree, Integer> pair: consolidatedActions.get(tree)){
                        trees.add(pair);
                    }
                    consolidatedActions.remove(tree);
                }
                consolidatedActions.put(parentTree, trees);
                if (!toVisit.contains(parentTree)) {
                    toVisit.add(parentTree);
                }

            }
            if (!consolidatedActions.containsKey(tree)){
                consolidatedActions.put(tree, new ArrayList<>());
            }
        }

        return consolidatedActions;
    }

    Pair<Tree, Integer> getTreePositionPair(Action action){
        Pair<Tree, Integer> pair;
        if (action instanceof Insert){
            Insert insert = (Insert) action;
            pair = new Pair<>(insert.getParent(), insert.getPosition());
        }
        else if (action instanceof TreeInsert) {
            TreeInsert treeInsert = (TreeInsert) action;
            pair = new Pair<>(treeInsert.getParent(), treeInsert.getPosition());
        }
        else {
            if (!action.getNode().isRoot()) {
                pair = new Pair<>(action.getNode().getParent(), action.getNode().getPos());
            }
            else {
                pair = new Pair<>(action.getNode(), action.getNode().getPos());
            }
        }
        return pair;
    }


    List<Action> getDiffPerPair(String file1, String file2) throws IOException {
        List<Action> actions = getActions(file1, file2);
        if (actionCleaningNeeded) {
            cleanListOfActions(actions);
        }
        //removeNotParsedCorrectly(actions);
        System.out.println("Node Changes collected.");

        if (actionCleaningNeeded && checkForRootChanges && !hasRootChanges){
            for (Action action: actions){
                checkIfRootChange(action);
            }
        }
        return actions;
    }

    /**
     * Function used to write actions to string to a file
     * later used to compare similarity
     * @param functionToActions
     */
    private void writeFunctions(HashMap<String, List<String>> functionToActions){
        Iterator<Map.Entry<String, List<String>>> iterator = functionToActions.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<String, List<String>> next = iterator.next();
            String key = next.getKey();
            String[] split = key.split("@");
            String fileName = processFilename(split[0]);
            key = fileName + "@" + split[1];
            List<String> value = next.getValue();
            for (String stringifiedAction: value){
                pw.write(key + ":&^" + stringifiedAction + "\n");
            }
        }
        pw.close();
    }

    private String sanitizeAction(String unsanitizedAction){
        Pattern firstMatch = Pattern.compile("\\[[\\d]+,[\\d]+\\]");
        Matcher matcher = firstMatch.matcher(unsanitizedAction);
        String sanitizedAction = unsanitizedAction;
        while(matcher.find()){
            String group = matcher.group(0);
            sanitizedAction = sanitizedAction.replaceAll(group.substring(1, group.length()-1), "");
        }
        sanitizedAction.replaceAll("\n", " ");
        Pattern secondMatch = Pattern.compile("at \\d");
        matcher = secondMatch.matcher(sanitizedAction);
           while(matcher.find()){
            String group = matcher.group(0);
            sanitizedAction = sanitizedAction.replaceAll(group, "");
        }
        return sanitizedAction.replaceAll("\n", " ");
    }

    private void gatherFunctions(HashMap<String, List<Action>> functionToActions, List<Action> actions, String fileName){
        for (Action action: actions){
            Tree function = getFunction(action.getNode());
            String functionName;
            if (function != null) {
                int paramNumbers = getNumberOfParamsPerFunction(function);
                if (action instanceof Update){
                    Update update = (Update) action;
                    if (update.getNode().getType().name.equals("GenericString") && !update.getNode().isRoot() &&
                            isCFunction(action.getNode().getParent())) {
                        functionName = fileName + "@" + update.getValue();
                    }
                    else{
                        functionName = fileName + "@" + getFunctionIdentifier(function);
                    }

                } else {
                    functionName = fileName + "@" + getFunctionIdentifier(function);
                }
                functionNameToParamNumber.put(functionName, paramNumbers);

            }
            else {
                functionName = fileName + "@" + "GLOBAL";
            }
            List<Action> functionNameActions;

            System.out.println(functionName);
            if (functionToActions.containsKey(functionName)) {
                functionNameActions = functionToActions.get(functionName);
            } else {
                functionNameActions = new ArrayList<>();
            }
            functionNameActions.add(action);
            functionToActions.put(functionName, functionNameActions);
        }
    }

    private int getNumberOfParamsPerFunction(Tree function){
        if (function == null){
            return -1;
        }
        if (language.equalsIgnoreCase("C")){
            return getNumberOfParamsPerCFunction(function);
        }
        // the process is the same for both CPP and H files
        if (language.equalsIgnoreCase("CPP") || language.equalsIgnoreCase("H")){
            return getNumberOfParamsPerCPPFunction(function);
        }
        return -1;
    }
    private int getNumberOfParamsPerCFunction(Tree function){
        Iterator<Tree> trees = function.breadthFirst().iterator();
        while (trees.hasNext()){
            Tree next = trees.next();
            if (next.getType().name.equalsIgnoreCase("ParamList")){
                return next.getChildren().size();
            }
        }
        return -1;
    }
    private int getNumberOfParamsPerCPPFunction(Tree function){
        Iterator<Tree> trees = function.breadthFirst().iterator();
        while (trees.hasNext()){
            Tree next = trees.next();
            if (next.getType().name.equalsIgnoreCase("parameter_list")){
                return next.getChildren().size();
            }
        }
        return -1;
    }

    private int getNumberOfArgumentsPerFunction(Tree function){
        if (function == null){
            return -1;
        }

        if (language.equalsIgnoreCase("C")){
            return getNumberOfArgumentsPerCFunction((function));
        }
        // the process is the same for both CPP and H files
        if (language.equalsIgnoreCase("CPP") || language.equalsIgnoreCase("H")){
            return getNumberOfArgumentsPerCPPFunction(function);
        }
        return -1;
    }
    private int getNumberOfArgumentsPerCFunction(Tree function){
        while (!function.getType().name.equalsIgnoreCase("FunCall") && !function.isRoot()){
            function = function.getParent();
        }
        Iterator<Tree> trees = function.breadthFirst().iterator();
        while (trees.hasNext()){
            Tree next = trees.next();
            if (next.getType().name.equalsIgnoreCase("GenericList")){
                return next.getChildren().size();
            }
        }
        return -1;
    }

    private int getNumberOfArgumentsPerCPPFunction(Tree function){
        while (!function.getType().name.equalsIgnoreCase("call") && !function.isRoot()){
            function = function.getParent();
        }
        Iterator<Tree> trees = function.breadthFirst().iterator();
        while (trees.hasNext()){
            Tree next = trees.next();
            if (next.getType().name.equalsIgnoreCase("argument_list")){
                return next.getChildren().size();
            }
        }
        return -1;
    }


    private String processFilename(String filename){
        return filename.split(project)[1].substring(8);
    }

    /**
     * Function to see which changes are related to the callgraph
     * build a graph where nodes are functions that have changed and directed edges represent calls that have somehow
     * changed
     * @param functionsToActions
     * @throws IOException
     */
    private void analyzeCallGraphChanges(HashMap<String, List<Action>> functionsToActions) throws IOException {
        // get a list of all function names
        // get their declaration trees and parameter list from the file
        // per each action, check if they're a call
        // check if they match one of the function names
        // check if the call list matches
        // if so, add the called function/macro as a destination edge from the callee function
        HashMap<String, List<String>> functionsToCalledFunctions = new HashMap<>();
        Iterator<String> iterator = functionsToActions.keySet().iterator();
        List<String> functions = new ArrayList<>();
        List<String> files = new ArrayList<>();
        List<Integer> params = new ArrayList<>();
        while(iterator.hasNext()){
            String next = iterator.next();
            String[] nextSplit = next.split("@");
            String processedFilename = processFilename(nextSplit[0]);
            if (functionNameToParamNumber.containsKey(next)) {
                files.add(nextSplit[0]);
                functions.add(nextSplit[1]);
                int param = functionNameToParamNumber.get(next);
                params.add(param);
                String fileAndFunctionName = processedFilename + "@" + nextSplit[1];
                functionsToCalledFunctions.put(fileAndFunctionName, new ArrayList<>());
            }
        }
        Iterator<Map.Entry<String, List<Action>>> entryIterator = functionsToActions.entrySet().iterator();
        while(entryIterator.hasNext()){
            Map.Entry<String, List<Action>> next = entryIterator.next();
            String fullFunctionName = next.getKey();
            String fileName = fullFunctionName.split("@")[0];
            String processedFunctionName = processFilename(fileName) + "@" + fullFunctionName.split("@")[1];
            setLanguage(fileName);
            List<Action> actions = next.getValue();
            for (Action action: actions){
                if (action.getNode().isRoot()){
                    continue;
                }
                if (action.getNode().getType().name.equalsIgnoreCase("FunCall") ||
                        (!action.getNode().isRoot() && checkIfFuncCallIsParentNode(action.getNode().getParent()))){
                    String calledFunction;
                    Tree node = action.getNode();
                    if (action instanceof Update){
                        Update update = (Update) action;
                        calledFunction = update.getValue();
                        if (fileToMappingStore.containsKey(fileName)) {
                            MappingStore m = fileToMappingStore.get(fileName);
                            node = m.getDstForSrc(update.getNode());
                            if (node == null){
                                node = m.getSrcForDst(update.getNode());
                            }
                        }
                    } else {
                        calledFunction = funCallIdentifier(action.getNode());
                    }
                    if (functions.contains(calledFunction)){
                        int indexOfCalledFunction = functions.indexOf(calledFunction);
                        int paramsOfCalledFunction = params.get(indexOfCalledFunction);
                        int argsOfCalleeFunction =
                                (node.getType().name.equalsIgnoreCase("FunCall") ||
                                        node.getType().name.equalsIgnoreCase("call")) ?
                                getNumberOfArgumentsPerFunction(node) :
                                        getNumberOfArgumentsPerFunction(node.getParent());
                        if (paramsOfCalledFunction == argsOfCalleeFunction){
                            // Not checking if the file's imported. We're making the assumption that if a call in
                            // the callee function is changed and that call has the same identifier as another
                            // changed function, then the called function is the changed function.
                            List<String> calledFunctions;
                            if (functionsToCalledFunctions.containsKey(processedFunctionName)){
                                calledFunctions = functionsToCalledFunctions.get(processedFunctionName);
                            }
                            else {
                                calledFunctions = new ArrayList<>();
                            }
                            String file = processFilename(files.get(indexOfCalledFunction));
                            String calledFunctionFullName = file + "@" + calledFunction;
                            if (!calledFunctions.contains(calledFunctionFullName)) {
                                calledFunctions.add(file + "@" + calledFunction);
                            }
                            functionsToCalledFunctions.put(processedFunctionName, calledFunctions);
                        }
                    }
                }
            }
        }

        PrintWriter callGraphWriter = new PrintWriter(new FileWriter(new File(callGraphOutput)));
        Iterator<Map.Entry<String, List<String>>> entryIterator1 = functionsToCalledFunctions.entrySet().iterator();
        while (entryIterator1.hasNext()){
            Map.Entry<String, List<String>> next = entryIterator1.next();
            String key = next.getKey();
            List<String> value = next.getValue();
            callGraphWriter.write(key + ";");
            for (String calledFunction: value){
                callGraphWriter.write(calledFunction + "\t");
            }
            callGraphWriter.write("\n");
        }
        callGraphWriter.close();
    }

}
