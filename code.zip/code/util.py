import pickle
import os

def dump_objects(object, output_file):
    pickle.dump(object, open(output_file, "wb"))


def load_objects(input_file):
    return pickle.load(open(input_file, "rb"))


def get_failure_file(output_file):
    return f"{os.path.dirname(output_file)}/failure"
